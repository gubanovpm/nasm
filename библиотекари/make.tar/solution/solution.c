#include <stdio.h>
int main(int argc) {
	return argc - 1;
}