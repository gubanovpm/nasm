#include <stdio.h>

int subroutine(int a, int b);
// extern int subroutine(int a, int b);

int main()
{
	printf("%d\n", subroutine(1, 5));

	return 0;
}